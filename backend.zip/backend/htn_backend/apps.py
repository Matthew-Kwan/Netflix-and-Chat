from django.apps import AppConfig


class HtnBackendConfig(AppConfig):
    name = 'htn_backend'
